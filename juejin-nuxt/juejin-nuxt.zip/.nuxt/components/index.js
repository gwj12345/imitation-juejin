export { default as Ad } from '../..\\components\\ad.vue'
export { default as Header } from '../..\\components\\Header.vue'
export { default as More } from '../..\\components\\more.vue'
export { default as SigninTip } from '../..\\components\\signin-tip.vue'
export { default as Tablead } from '../..\\components\\tablead.vue'
export { default as UpdateIcon } from '../..\\components\\update-icon.vue'
export { default as ArticlesArticleBody } from '../..\\components\\articles\\article-body.vue'
export { default as ArticlesArticleCatalog } from '../..\\components\\articles\\article-catalog.vue'
export { default as ArticlesArticleContent } from '../..\\components\\articles\\article-content.vue'
export { default as ArticlesArticleLeftbar } from '../..\\components\\articles\\article-leftbar.vue'
export { default as ArticlesLeftbars } from '../..\\components\\articles\\leftbars.vue'
export { default as MainnavClearBorder } from '../..\\components\\mainnav\\clear-border.vue'
export { default as MainnavHomepageItem } from '../..\\components\\mainnav\\homepage-item.vue'
export { default as MainnavMainNav } from '../..\\components\\mainnav\\main-nav.vue'
export { default as MainnavUpdateIcon } from '../..\\components\\mainnav\\update-icon.vue'
export { default as HomeitemsItem } from '../..\\components\\homeitems\\item.vue'
export { default as NuxtHelloWorld } from '../..\\components\\nuxt\\HelloWorld.vue'
export { default as NuxtLogo } from '../..\\components\\nuxt\\NuxtLogo.vue'
export { default as NuxtTutorial } from '../..\\components\\nuxt\\Tutorial.vue'
export { default as NavlistNavList } from '../..\\components\\navlist\\nav-list.vue'
export { default as NavlistOrdinary } from '../..\\components\\navlist\\ordinary.vue'
export { default as NavlistRightItem } from '../..\\components\\navlist\\right-item.vue'
export { default as NavlistTextPrimary } from '../..\\components\\navlist\\text-primary.vue'
export { default as NavlistWiden } from '../..\\components\\navlist\\widen.vue'
export { default as QrcodeDownload } from '../..\\components\\qrcode\\qrcode-download.vue'
export { default as MainnavNavItems } from '../..\\components\\mainnav\\nav-items\\nav-items.vue'
export { default as ArticlesRightbarsArticleAds } from '../..\\components\\articles\\rightbars\\article-ads.vue'
export { default as ArticlesRightbarsArticleCatalog } from '../..\\components\\articles\\rightbars\\article-catalog.vue'
export { default as ArticlesRightbarsInformation } from '../..\\components\\articles\\rightbars\\information.vue'
export { default as ArticlesRightbarsRightbar } from '../..\\components\\articles\\rightbars\\rightbar.vue'

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
