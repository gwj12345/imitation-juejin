# Discovered Components

This is an auto-generated list of components discovered by [nuxt/components](https://github.com/nuxt/components).

You can directly use them in pages and other components without the need to import them.

**Tip:** If a component is conditionally rendered with `v-if` and is big, it is better to use `Lazy` or `lazy-` prefix to lazy load.

- `<Ad>` | `<ad>` (components/ad.vue)
- `<Header>` | `<header>` (components/Header.vue)
- `<More>` | `<more>` (components/more.vue)
- `<SigninTip>` | `<signin-tip>` (components/signin-tip.vue)
- `<Tablead>` | `<tablead>` (components/tablead.vue)
- `<UpdateIcon>` | `<update-icon>` (components/update-icon.vue)
- `<ArticlesArticleBody>` | `<articles-article-body>` (components/articles/article-body.vue)
- `<ArticlesArticleCatalog>` | `<articles-article-catalog>` (components/articles/article-catalog.vue)
- `<ArticlesArticleContent>` | `<articles-article-content>` (components/articles/article-content.vue)
- `<ArticlesArticleLeftbar>` | `<articles-article-leftbar>` (components/articles/article-leftbar.vue)
- `<ArticlesLeftbars>` | `<articles-leftbars>` (components/articles/leftbars.vue)
- `<MainnavClearBorder>` | `<mainnav-clear-border>` (components/mainnav/clear-border.vue)
- `<MainnavHomepageItem>` | `<mainnav-homepage-item>` (components/mainnav/homepage-item.vue)
- `<MainnavMainNav>` | `<mainnav-main-nav>` (components/mainnav/main-nav.vue)
- `<MainnavUpdateIcon>` | `<mainnav-update-icon>` (components/mainnav/update-icon.vue)
- `<HomeitemsItem>` | `<homeitems-item>` (components/homeitems/item.vue)
- `<NuxtHelloWorld>` | `<nuxt-hello-world>` (components/nuxt/HelloWorld.vue)
- `<NuxtLogo>` | `<nuxt-logo>` (components/nuxt/NuxtLogo.vue)
- `<NuxtTutorial>` | `<nuxt-tutorial>` (components/nuxt/Tutorial.vue)
- `<NavlistNavList>` | `<navlist-nav-list>` (components/navlist/nav-list.vue)
- `<NavlistOrdinary>` | `<navlist-ordinary>` (components/navlist/ordinary.vue)
- `<NavlistRightItem>` | `<navlist-right-item>` (components/navlist/right-item.vue)
- `<NavlistTextPrimary>` | `<navlist-text-primary>` (components/navlist/text-primary.vue)
- `<NavlistWiden>` | `<navlist-widen>` (components/navlist/widen.vue)
- `<QrcodeDownload>` | `<qrcode-download>` (components/qrcode/qrcode-download.vue)
- `<MainnavNavItems>` | `<mainnav-nav-items>` (components/mainnav/nav-items/nav-items.vue)
- `<ArticlesRightbarsArticleAds>` | `<articles-rightbars-article-ads>` (components/articles/rightbars/article-ads.vue)
- `<ArticlesRightbarsArticleCatalog>` | `<articles-rightbars-article-catalog>` (components/articles/rightbars/article-catalog.vue)
- `<ArticlesRightbarsInformation>` | `<articles-rightbars-information>` (components/articles/rightbars/information.vue)
- `<ArticlesRightbarsRightbar>` | `<articles-rightbars-rightbar>` (components/articles/rightbars/rightbar.vue)
