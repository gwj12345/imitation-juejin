<template>
    <div class="tablead">
       <span>邀请有礼</span>
    </div>
</template>

<script>

</script>
<style>
.tablead{
    position: absolute;
    top: 5px;
    left: 7px;
    z-index: 9;
    white-space: nowrap;
    padding: 2px 7px;
    background-color: #ee502f;
    border-radius: 50px;
    text-align: center;
    font-weight: 500;
    font-size: 16px;
    transform: scale(.5);
    line-height: 18px;
    color: #fff;
}
@media (max-width: 768px) {

}

</style>