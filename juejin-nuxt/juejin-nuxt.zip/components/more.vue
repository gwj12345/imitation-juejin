<template>
  <div>
    <div class="aside-footer">
      <ul class="more-list">
        <li class="item">
          <a href="javascript:;" target="_blank">用户协议</a>
        </li>
        <li class="item">
          <a href="javascript:;" target="_blank"> 营业执照 </a>
        </li>
        <li class="item">
          <a href="javascript:;" target="_blank">隐私政策</a>
        </li>
        <li class="item">
          <a href="javascript:;" target="_blank">关于我们</a>
        </li>
      </ul>
      <ul class="more-list">
        <li class="item">
          <a st:name="sitemap" href="javascript:;" target="_blank">站点地图</a>
        </li>
        <li class="item">
          <a st:name="guideLink" href="javascript:;" target="_blank">
            使用指南
          </a>
        </li>
        <li class="item">
          <a href="javascript:;" target="_blank" rel="">友情链接</a>
        </li>
        <li class="item">
          <a href="javascript:;" target="_blank" rel=""> 更多文章 </a>
        </li>
      </ul>
      <ul class="more-list">
        <li class="item">
          <a href="javascript:;" target="_blank"> 京ICP备18012699号-3 </a>
        </li>
      </ul>
      <ul class="more-list">
        <li class="item">
          <a href="javascript:;" target="_blank"
            ><img
              src="../assets/images/gongan.png"
              alt="police"
              style="vertical-align: middle"
            />
            渝公网安备xxxxxxxxxxxxx号
          </a>
        </li>
        <li class="item">
          <span>版权所有：xxxxxxxxxxxxx有限公司</span>
        </li>
        <li class="item">
          <span>公司地址：xxxxxxxxxxxxxxxxxxxxxxxxxx</span>
        </li>
        <li class="item"><span>公司座机：xxxxxxxxxxxxx</span></li>
        <li class="item">
          <span>
            举报邮箱：
            <a href="javascript:;">xxxxxxxxxxxxx</a></span
          >
        </li>
      </ul>
      <ul class="more-list">
        <li class="item"><a>©2022 稀土掘金</a></li>
      </ul>
      <ul class="more-list">
        <li class="item weibo">
          <img src="../assets/images/weibo.png" alt="微博" class="icon" />
        </li>
        <li class="item wechat">
          <img src="../assets/images/wechat.png" alt="微信" class="icon" />
        </li>
      </ul>
    </div>
  </div>
</template>

<style scoped>
@import "../assets/css/main.css";
@import "../assets/css/index.css";
@import "../assets/css/font-awesome-4.7.0/css/font-awesome.min.css";
</style>