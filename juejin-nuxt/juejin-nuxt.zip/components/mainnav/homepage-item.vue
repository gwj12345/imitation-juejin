<template>
    <div>
        <ul>
          <li><a href="/" class="text-primary">{{name}}</a></li>
        </ul>
    </div>
</template>

<script>
export default{
    name:"Homepageitem",
    props:['name']
    
}

</script>
<style>

</style>