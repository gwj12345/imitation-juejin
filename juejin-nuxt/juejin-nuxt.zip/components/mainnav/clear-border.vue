<template>
    <li id="clear-border">
            <a href="https://juejin.cn/vip?utm_source=web_nav" target="_blank">
            <img src="../../assets/images/zoom.png" alt="" width="80"/>
            </a>
    </li> 
</template>

<script>

</script>
<style>

</style>