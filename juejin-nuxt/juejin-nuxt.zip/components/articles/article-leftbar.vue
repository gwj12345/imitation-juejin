<template>
    <div class="icons">
      <button
        class="button circle"
        aria-disabled="false"
        type="button"
      >
      <i><svg t="1677073341203" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="3538" width="200" height="200"><path d="M64 483.04V872c0 37.216 30.144 67.36 67.36 67.36H192V416.32l-60.64-0.64A67.36 67.36 0 0 0 64 483.04zM857.28 344.992l-267.808 1.696c12.576-44.256 18.944-83.584 18.944-118.208 0-78.56-68.832-155.488-137.568-145.504-60.608 8.8-67.264 61.184-67.264 126.816v59.264c0 76.064-63.84 140.864-137.856 148L256 416.96v522.4h527.552a102.72 102.72 0 0 0 100.928-83.584l73.728-388.96a102.72 102.72 0 0 0-100.928-121.824z" p-id="3539" fill="#8a8a8a"></path></svg></i>
      </button>
      
    </div>
</template>

<script>

export default{
    name:"ArticleLeftbar",
    props:['svg']
    
}
</script>

<style>
.container {
  display: flex;
  flex-direction: column;
  position: sticky;
  top: 20px;
}
.icons {
  margin: 10px 5px 5px 20px;
}
svg.icon{
    height:40px;
    margin-top:-10px;
    margin-left:-5px;
}

.circle{
    border:none;
}
.button{
  width:40px;
  height: 40px;
  padding:12px;
  border-radius: 50%;
  font-size: 14px;
}
</style>