<template>
    <div class="info">
      <span
        ><a href="https://juejin.cn/user/3602460700059213"
          ><img
            src="https://pic.imgdb.cn/item/63eb263ef144a01007104f0c.png"
            alt="" /></a
      ></span>
      掘金酱
    </div>

</template>

<script>

</script>

<style>
.info{
    background-color: white;
    height: 5rem;
    line-height: 5rem;
    margin-bottom:20px;
    padding-left:20px
}

.info img {
    width: 60px;
    border-radius: 50%;
    margin-top: -6px;
}

</style>