<template>
    <div class="update-icon">
        <img src="../assets/images/update-icon.svg" alt="">
    </div>
</template>

<script>

</script>
<style>

@media (max-width: 768px) {
.update-icon{
        display: none;
} 
}

</style>