<template>
    <div>
        <ul class="nav-list clearfix">
          <li><a href="javascript:;" class="text-primary">{{name}}</a></li>
        </ul>
    </div>
</template>

<script>
export default{
    name:"Textprimary",
    props:['name']
    
}

</script>
<style>

</style>