<template>
    <div>
        <ul class="nav-list clearfix">
          <li><a href="javascript:;">{{name}}</a></li>
        </ul>
    </div>
</template>

<script>
export default{
    name:"Ordinary",
    props:['name']
    
}

</script>
<style>

</style>